<?php
// Mostrar mensajes flash
showFlashMessages();
?>