<?php
// Vista transactions/index.php
$pageTitle = 'Transactions';
include __DIR__ . '/../layouts/header.php';
?>

<div class='card'>
  <h2>Transactions</h2>
  <p>Contenido pendiente.</p>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
