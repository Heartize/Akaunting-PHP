<?php
// Vista transactions/show.php
$pageTitle = 'Detalles de Transaction';
include __DIR__ . '/../layouts/header.php';
?>

<div class='card'>
  <h2><?php echo $pageTitle; ?></h2>
  <!-- Detalles pendientes -->
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
