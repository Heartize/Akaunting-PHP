<?php
// Vista products/index.php
$pageTitle = 'Products';
include __DIR__ . '/../layouts/header.php';
?>

<div class='card'>
  <h2>Products</h2>
  <p>Contenido pendiente.</p>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
