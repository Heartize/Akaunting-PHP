<?php
// Vista clients/show.php
$pageTitle = 'Detalles de Client';
include __DIR__ . '/../layouts/header.php';
?>

<div class='card'>
  <h2><?php echo $pageTitle; ?></h2>
  <!-- Detalles pendientes -->
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
